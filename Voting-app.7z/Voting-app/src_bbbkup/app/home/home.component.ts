import { DataParserApiService } from './../data-parser-api.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/Router';
import { FormGroup, FormControl, Validators } from '@angular/Forms';

@Component({
  selector: 'home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  lastId: number;
  pollList: any[] = [];

  form = new FormGroup({
    title: new FormControl('', Validators.required),
    name: new FormControl('', Validators.required)
  });

  constructor(private router: Router, private pollsList: DataParserApiService) { }

  ngOnInit() {
    this.pollsList.getPollList().subscribe(data => {
      console.log(data.json());
      this.pollList = data.json();
    })
  }

  get title() {
    return this.form.get('title');
  }

  get name() {
    return this.form.get('name');
  }

  onSubmit(e) {
    console.log(this.form);
    var objToPost = {};
    objToPost = this.form.value;
    objToPost['id'] = this.pollList[this.pollList.length-1].id + 1;
    this.pollsList.postPollList(objToPost)
      .subscribe(response => {
        var resp = response.json();
        console.log(resp);
        this.pollList.push(resp);
        this.pollsList.setDataInTable(this.pollList);
        this.router.navigate(['/polls-list']);
      })
  }

}
