import { DataParserApiService } from './../data-parser-api.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'polls-list',
  templateUrl: './polls-list.component.html',
  styleUrls: ['./polls-list.component.css']
})
export class PollsListComponent implements OnInit {
  data: any[] = [];

  constructor(private pollsListService: DataParserApiService) { }

  ngOnInit() {
    this.data = this.pollsListService.getDataInTable();
  }

}
