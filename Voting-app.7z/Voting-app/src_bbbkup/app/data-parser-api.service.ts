import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

@Injectable({
  providedIn: 'root'
})
export class DataParserApiService {
  url: string = "http://localhost:3000/pollsList";
  pollListDataInService: any[] = [];
  constructor(private http: Http) { }

  getPollList() {
    return this.http.get(this.url);
  }

  postPollList(pollObject) {
    console.log(pollObject);
    return this.http.post(this.url, pollObject);
  }
  
  setDataInTable(pollList) {
    this.pollListDataInService = pollList;
  }

  getDataInTable() {
    return this.pollListDataInService
  }
  
}

